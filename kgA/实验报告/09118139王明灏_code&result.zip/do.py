import pandas as pd

csv_files = ["college.csv", "major.csv", "displine.csv", "province.csv", "subject.csv", "year.csv"]

for i in csv_files:
    file_path = 'D:\\大三上\\明明\\preprocess\\entity\\' + i
    csv_file = pd.read_csv(file_path, encoding='gbk')
    csv_df = pd.DataFrame(csv_file)
    #print(csv_df)
    #for item in csv_df.iloc[1:,1]:
     #   item = "\"" + item + "\""
    csv_df.to_csv('D:\\大三上\\明明\\result\\'+i, index=False, quoting = 1)
    #print('------------------------')
    #print(csv_df)