# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import pandas as pd
file_path = 'D:\\seu-2020\\softwarepractise\\preprocess\\entity\\'
file_name= 'college.csv'
file=file_path+file_name
csv_file=pd.read_csv(file, encoding='utf-8')
csv_df=pd.DataFrame(csv_file)
csv_df.rename(columns={'College:ID':'CollegeID:ID','label':'CollegeName','985':'985:int','211':'211:int','top':'Top:int'},inplace=True)
csv_df[':LABEL']='college'
csv_df.to_csv('D:\\seu-2020\\softwarepractise\\result'+file_name, index=False,encoding='utf-8',quoting = 1)

file_name='displine.csv'
csv_file=pd.read_csv(file, encoding='utf-8')
csv_df=pd.DataFrame(csv_file)
csv_df.rename(columns={'Displine:ID':'DisplineID:ID','label':'DisplineName'},inplace=True)
csv_df[':LABEL']='First-level discipline'
csv_df.to_csv('D:\\seu-2020\\softwarepractise\\result'+file_name, index=False,encoding='utf-8',quoting = 1)

file_name='belong_to.csv'
csv_file=pd.read_csv(file, encoding='utf-8')
csv_df=pd.DataFrame(csv_file)
csv_df.drop(['belong_to'],axis=1,inplace=True)
csv_df.to_csv('D:\\seu-2020\\softwarepractise\\result'+file_name, index=False,encoding='utf-8',quoting = 1)

file_name='is_subject.csv'
csv_file=pd.read_csv(file, encoding='utf-8')
csv_df=pd.DataFrame(csv_file)
csv_df.drop(['is_subject'],axis=1,inplace=True)
csv_df.rename({'IS_SUBJECT'=':TYPE'},inplace=True)
csv_df.to_csv('D:\\seu-2020\\softwarepractise\\result'+file_name, index=False,encoding='utf-8',quoting = 1)

file_name='has.csv'
csv_file=pd.read_csv(file, encoding='utf-8')
csv_df=pd.DataFrame(csv_file)
csv_df.drop(['has'],axis=1,inplace=True)
csv_df.to_csv('D:\\seu-2020\\softwarepractise\\result'+file_name, index=False,encoding='utf-8',quoting = 1)















